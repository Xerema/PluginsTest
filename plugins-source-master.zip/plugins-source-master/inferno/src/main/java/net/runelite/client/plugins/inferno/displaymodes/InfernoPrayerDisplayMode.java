package net.runelite.client.plugins.inferno.displaymodes;

public enum InfernoPrayerDisplayMode
{
	PRAYER_TAB,
	BOTTOM_RIGHT,
	BOTH
}
