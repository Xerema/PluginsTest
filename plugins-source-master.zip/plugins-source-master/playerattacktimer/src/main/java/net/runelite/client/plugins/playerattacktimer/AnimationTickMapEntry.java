package net.runelite.client.plugins.playerattacktimer;

public class AnimationTickMapEntry
{
	Integer delay;
	AttackPrayer prayer;

	public AnimationTickMapEntry(Integer delay, AttackPrayer prayer)
	{
		this.delay = delay;
		this.prayer = prayer;
	}
}
