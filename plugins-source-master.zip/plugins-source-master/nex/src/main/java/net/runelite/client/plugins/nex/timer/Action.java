package net.runelite.client.plugins.nex.timer;

@FunctionalInterface
public interface Action
{
	void method();
}
