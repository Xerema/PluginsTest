package net.runelite.client.plugins.nex;

@FunctionalInterface
interface NexOverlayAction
{
	void method(boolean value);
}
